# pyempfin
Version: 0.1

Helper functions for empirical finance research using Python.
